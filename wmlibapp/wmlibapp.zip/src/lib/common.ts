interface IAPIMeta {
    code : number;
    message : string
}
interface IAPIResponse{
    meta : IAPIMeta,
    data : Array <any>
}

 
